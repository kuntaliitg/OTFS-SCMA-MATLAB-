function symbol_indices_hat=SCMA_detection_MPA_LLR_domain(yr,sigma_2,h_matrix,max_iter,C,K,N,M,cf)
F=(h_matrix~=0);
y=reshape(yr,N*M,1);
No_VNs=size(F,2);   % J is the number of users
No_CNs=size(F,1);   % K is the number of resources
power_users=ones(1,No_VNs);
N0=sigma_2*2;
M_mod=4;
%% Intialization
V_initial=zeros(No_CNs*M_mod,No_VNs);   % equally likely
V=V_initial; % Initialize V
U=zeros(No_CNs*M_mod,No_VNs);  % contains resource_node->layer_node messages
V_posterior=zeros(M_mod,No_VNs);  % contains the posterior probabilities 
symbol_indices_hat=zeros(No_VNs,1);
for itr=1:max_iter
    V_posterior_prev=V_posterior; % to check for convergence
    %% Resource node/ check node update  (Written only for degree-3 CN)
    for k=1:No_CNs          % for each CN 
        k_eff=rem(k-1,K)+1; % effective k value within a codebook
        del_k=find(F(k,:));  %set of neighboring layer nodes connected to the kth resource node
        d_f=length(del_k);  % number of neighboring VNs of the  CN
        for j=1:length(del_k) % for each neighboring VN connected to the kth CN
            pr_j=del_k(j);  % pr_j is the present layer node connected to kth resource node 
            pr_j_user=floor((pr_j-1)/(M*N/K))+1;
            pr_codebook=C((pr_j_user-1)*K+1:pr_j_user*K,:);  % codebook for the pr_jth user
            del_k_min_j=setdiff(del_k,pr_j);  % set of extrinsic neighboring users/VNs
            V_neigh_mat=zeros(M_mod,(d_f-1)); % extrinsic input V messages from the VNs to the kth CN stored in matrix
            for v_ind=1:d_f-1
                pr_VN_neigh=del_k_min_j(v_ind);
                V_neigh_mat(:,v_ind)=V((k-1)*M_mod+1:k*M_mod,pr_VN_neigh);
            end
            for m=1:M_mod
                pr_codeword=pr_codebook(:,m);  % x_jm
                M_t=M_mod^(d_f-1);   %total number of combinations
                U_sum=zeros(1,M_t);    %  sum of the terms for CN->VN message                            
                for m_ind=1:M_t
                    arg1=y(k)-sqrt(power_users(pr_j))*h_matrix(k,pr_j)*pr_codeword(k_eff); 
                    c_indices=zeros(1,d_f-1);   % combination vector
                    pr_m=m_ind-1;
                    for c_ind=1:d_f-1
                        rem_pr=rem(pr_m,M_mod);
                        c_indices(c_ind)=rem_pr+1;
                        pr_m=floor(pr_m/M_mod);                
                    end
                    inner_sum_term=0+0i;
                    for d_ind=1:d_f-1
                        pr_VN=del_k_min_j(d_ind);
                        pr_VN_user=floor((pr_VN-1)/(M*N/K))+1;
                        codebook_neigh_pr_VN=C((pr_VN_user-1)*K+1:pr_VN_user*K,:);
                        codeword_neigh_pr_VN=codebook_neigh_pr_VN(:,c_indices(d_ind));
                        inner_sum_term=inner_sum_term+sqrt(power_users(pr_VN))*h_matrix(k,pr_VN)*codeword_neigh_pr_VN(k_eff);
                    end
                    arg1=arg1-inner_sum_term;
                    T1=-1/N0*(abs(arg1))^2; % the common term
                    T2=0;
                    for d_ind=1:d_f-1
                        T2=T2+V_neigh_mat(c_indices(d_ind),d_ind);
                    end
                    U_sum(m_ind)=T1+T2;
                end
                U_sum(abs(U_sum)>=cf)=cf*sign(U_sum(abs(U_sum)>=cf)); 
                U((k-1)*M_mod+m,pr_j)=log(sum(exp(U_sum)));   % message update
            end
            U((k-1)*M_mod+1:k*M_mod,pr_j)=U((k-1)*M_mod+1:k*M_mod,pr_j)-log(sum(exp(U((k-1)*M_mod+1:k*M_mod,pr_j)))); % normalization
        end
    end                   
    
    %% Layer node/ variable node update
    for j=1:No_VNs   % for each VN
        del_j=find(F(:,j));  %set of neighboring resource nodes connected to the jth layer node
        for k=1:length(del_j) %for each neigboring CN connected to the jth VN
            pr_k=del_j(k);  % pr_k is the present resource node connected to kth layer node
            del_j_min_k=setdiff(del_j',pr_k);  % set of extrinsic neighboring resource nodes/CNs
            V_message=zeros(M_mod,1);
            for m=1:M_mod
                T2=1;
                for k1=1:length(del_j_min_k)
                    pr_k1=del_j_min_k(k1);  % present extrinsic neighboring CN
                    U_neigh_pr_k1=U((pr_k1-1)*M_mod+1:pr_k1*M_mod,j);  % message from the neighbor pr_k1 to jth layer node
                    T2=T2+U_neigh_pr_k1(m);
                end
                V_message(m)=T2;   % a priori LLR is 0
            end
            V_message=V_message - log(sum(exp(V_message))); % normalization 
            V((pr_k-1)*M_mod+1:pr_k*M_mod,j)=V_message;
        end
    end
    %% Computation of the aposterior probabilities
    for j=1:No_VNs
        del_j=find(F(:,j));  %set of neighboring resource nodes connected to the jth layer node
        for m=1:M_mod
            T2=0;
            for k=1:length(del_j)
                pr_k=del_j(k);  % pr_k is the present resource node connected to jth layer node
                U_neigh_pr_k=U((pr_k-1)*M_mod+1:pr_k*M_mod,j);
                T2=T2+U_neigh_pr_k(m);
            end
        V_posterior(m,j)=T2;  
        end
        V_posterior(:,j)=V_posterior(:,j)-log(sum(exp(V_posterior(:,j))));
    end

%% Check for convergence
    check_value=sum(sum(abs(V_posterior_prev-V_posterior)));
    if check_value<0.0001         % stopping rule        
        break;
    end
end
%% Estimates of the codeword
max_values=max(V_posterior);
for j=1:No_VNs
    for m=1:M_mod
        if V_posterior(m,j)==max_values(j)
            symbol_indices_hat(j)=m-1;
            break;
        end
    end
end     
