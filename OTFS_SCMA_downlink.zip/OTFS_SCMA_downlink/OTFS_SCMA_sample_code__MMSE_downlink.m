%%  This is the code for the following paper:
%K. Deka, A. Thomas and S. Sharma, 
%"OTFS-SCMA: A Code-Domain NOMA Approach for Orthogonal Time Frequency Space Modulation," 
%in IEEE Transactions on Communications, vol. 69, no. 8, pp. 5043-5058, Aug. 2021
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
clear all
close all
tic

%% OTFS parameters%%%%%%%%%%
% number of symbol 
N = 8; % Doppler
% number of subcarriers
M = 8;  % Delay
% size of constellation
M_mod = 4;
M_bits = log2(M_mod);
% average energy per data symbol
eng_sqrt = (M_mod==2)+(M_mod~=2)*sqrt((M_mod-1)/6*(2^2));
% % number of symbols per frame
% N_syms_perfram = N*M;
% % number of bits per frame
% N_bits_perfram = N*M*M_bits;
%%  SCMA parameters  %%   
%load('DE_codebook_J12_K6_2.mat','C');  % SCMA codebook
%J=12; K=6; 
load('codebook_J6_K4.mat','C');  % SCMA codebook
J=6; K=4; 
F=get_indicator_matrix_factor_graph(C, J, K);  
% number of symbols per frame per user
N_syms_perfram_per_user = N*M/K;     % overloaded system with overloading factor J/K
% number of bits per frame per user
N_bits_perfram_per_user = N_syms_perfram_per_user*M_bits;

SNR_dB = 5:5:30;
SNR = 10.^(SNR_dB/10);
noise_var_sqrt = sqrt(1./SNR);
sigma_2 = abs(eng_sqrt*noise_var_sqrt).^2;
%%
max_error=[3000,1000, 1000, 1000, 1000,800,500,400, 600,100];
%rng(1)

n_ite=10;
err_ber = zeros(length(SNR_dB),1);
cf=10000;
for iesn0 = 1:length(SNR_dB)
    N_fram = 0;
    while err_ber(iesn0)<max_error(iesn0)
        %% random input bits generation%%%%%
        data_info_bit=(-1)*ones(N_bits_perfram_per_user,J);
        data_info_symbol=(-1)*ones(N_syms_perfram_per_user,J);
        %% Encoding
        x=zeros(N,M);  %   matrix of modulated symbols of all users
        for j=1:J
            data_info_bit(:,j) = randi([0,1],N_bits_perfram_per_user,1);
            data_info_symbol(:,j) = bi2de(reshape(data_info_bit(:,j),N_syms_perfram_per_user,M_bits));
            x_temp=zeros(K,N_syms_perfram_per_user);
            for ss=1:N_syms_perfram_per_user
                pr_data=data_info_symbol(ss,j)+1;  % +1 because MATLAB index starts from 1 \
                pr_codeword=C((j-1)*K+1:j*K,pr_data);
                x_temp(:,ss)=pr_codeword;
            end
            x_j=reshape(x_temp,N,M);
            x=x+x_j;   %x is the superimposed signal
        end
                    
%         x = qammod(data_temp,M_mod,0,'gray');
%         x = reshape(x,N,M);
        
        %% OTFS modulation%%%%
        s = OTFS_modulation(N,M,x);
        
        %% OTFS channel generation%%%%
        taps=4;
        delay_taps=0:taps-1;
        Doppler_taps=0:taps-1;
        [chan_coef] = OTFS_channel_gen(N,M,taps);
        
        %% OTFS channel output%%%%%        
        r = OTFS_channel_output(N,M,taps,delay_taps,Doppler_taps,chan_coef,sigma_2(iesn0),s);
        %r = OTFS_channel_output_ideal(N,M,taps,delay_taps,Doppler_taps,chan_coef,sigma_2(iesn0),s); % ideal pulse
        %% OTFS demodulation%%%%
        y = OTFS_demodulation(N,M,r); 
        
        %% Computation of H for OTFS %%%%
        H_rect=find_effective_H_rect_new(delay_taps,Doppler_taps,chan_coef,M,N);        
        %H_rect=find_effective_H_rect_new_ideal_pulse(delay_taps,Doppler_taps,chan_coef,M,N);% idela pulse
        %% MMSE detector OTFS
        xsum_est=OTFS_detection_MMSE_exact_op(y,sigma_2(iesn0),H_rect,N,M);    % simple MMSE detector giving exact output
        %% Computation of H for SCMA
        H_rect1=eye(M*N);  % simple AWGN now
        H_eff=find_effective_H_rect_downlink_SCMA(H_rect1,F,J,K,M,N);        
        %% message passing detector%%%%
        %x_est = OTFS_mp_detector_uplink_SCMA(H_eff,C,N,M,K,sigma_2(iesn0),y,n_ite);  % x_est is serial or a vector 
        %x_est=OTFS_SCMA_detection_MPA_prob_domain_mex(xsum_est,sigma_2(iesn0),H_eff,n_ite,M_mod,C,N,M,K);  %probability_domain
        x_est=SCMA_detection_MPA_LLR_domain_N8_M8_mex(xsum_est,sigma_2(iesn0),H_eff,n_ite,M_mod,C,K,N,M,cf);   % LLR domain
        %x_est=OTFS_SCMA_detection_MPA_LLR_domain_mex(xsum_est,sigma_2(iesn0),H_eff,n_ite,C,K,N,M,cf);   % LLR domain
        
        %% output bits and errors count%%%%%
        %data_demapping = qamdemod(x_est,M_mod);
        %data_demapping=x_est;
        %data_temp_est=zeros(data_temp,1);
        data_info_symbol_serial=reshape(data_info_symbol, N_syms_perfram_per_user*J,1);
        data_info_bit_serial=reshape(de2bi(data_info_symbol_serial,M_bits),N_bits_perfram_per_user*J,1);
        data_info_bit_serial_est = reshape(de2bi(x_est,M_bits),N_bits_perfram_per_user*J,1);
        errors = sum(xor(data_info_bit_serial_est,data_info_bit_serial));
        if errors~=0
            err_ber(iesn0) = errors + err_ber(iesn0);  
            fprintf('\n %d  bit errors collected',err_ber(iesn0));
        end
        N_fram=N_fram+1;
    end
    err_ber_fram(iesn0) = err_ber(iesn0)/(N_bits_perfram_per_user*J*N_fram);    
end
    


semilogy(SNR_dB, err_ber_fram,'-*','LineWidth',2);
title(sprintf('OTFS'))
ylabel('BER'); xlabel('SNR in dB');grid on

toc