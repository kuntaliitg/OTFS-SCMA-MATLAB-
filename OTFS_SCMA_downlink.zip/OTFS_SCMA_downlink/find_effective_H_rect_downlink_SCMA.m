function H_eff=find_effective_H_rect_downlink_SCMA(H_rect,F,J,K,M,N)
H_eff1=zeros(M*N,M*N*J/K);
for y_ind=1:M*N    % for every received value
    %effective_CN=rem(y_ind-1,K)+1;
    
    
    neigh_yind=find(H_rect(y_ind,:));
    for col_ind=1:length(neigh_yind)
        col=neigh_yind(col_ind);
        current_block=floor((col-1)/K)+1;
        eff_k_current_block_col_index=rem(col-1,K)+1;
        %current_cols_part=(current_block-1)*K+1:current_block*K
        neigh_eff_k=find(F(eff_k_current_block_col_index,:));
        pr_VNs=(current_block-1)*J+neigh_eff_k;
        H_eff1(y_ind,pr_VNs)=H_rect(y_ind,col);
    end
end

[No_CNs, No_VNs]=size(H_eff1);
 H_eff=zeros(No_CNs, No_VNs);
 cols_perm=zeros(No_VNs,1); 
 col1=0;
 for j=1:J
     for group=1:M*N/K
         col1=col1+1;
         col2=(group-1)*J+j;
         cols_perm(col1)=col2;
     end
 end
 
 for col=1:No_VNs
     H_eff(:,col)=H_eff1(:,cols_perm(col));     
 end
        
        
        
   
            
                
                
                
            
            
            
    








end