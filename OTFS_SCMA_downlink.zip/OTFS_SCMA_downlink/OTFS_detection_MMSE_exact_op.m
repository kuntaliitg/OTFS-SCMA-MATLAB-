function x_est=OTFS_detection_MMSE_exact_op(yr,sigma_2,H,N,M)
y=reshape(yr,N*M,1);
% C=reshape(H*H',N*M,N*M);
% B=(C+sigma_2*eye(M*N));
G=H'/(H*H'+sigma_2*eye(M*N));
x=G*y;
x_est=reshape(x,N,M);
end